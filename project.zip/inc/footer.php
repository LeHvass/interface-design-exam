<footer>
  <div class="motto">
    Book with ease.<br>
    Book with us.
  </div>

  <nav>
    <div>
      <a href="#">Contact Us</a>
      <span>John Boulevard 123</span>
      <span>3204, CA</span>
      <span>123 123 123</span>
    </div>
    <div>
      <a href="#">Customer Service</a>
      <a href="#">About Booking.com</a>
      <a href="#">Terms & Conditions</a>
      <a href="#">Privacy & Cookie Statement</a>
    </div>
  </nav>

</footer>