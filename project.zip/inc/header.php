<header>
  <a href="../project/">
    <img class="logo" src="images/booking-for-business-logo.png">
  </a>
  <nav>
    <a href="" class="primary">Edit Business</a>
    <a href="">DKK</a>
    <a href=""><img class="flag" src="images/flag-da.png"></a>
    <a href="">Contact</a>
    <a href="">Profile</a>
  </nav>
</header>